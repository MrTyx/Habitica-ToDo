# Habitica-ToDo
Chrome Extension to create a Habitica ToDo item using the current URL.


# Credit

1. Notifications Sounds
⋅⋅* Success_1.mp3 https://notificationsounds.com/message-tones/filling-your-inbox-251
⋅⋅* Success_2.mp3 https://notificationsounds.com/notification-sounds/job-done-501
⋅⋅* Success_3.mp3 https://notificationsounds.com/message-tones/all-eyes-on-me-465

2. Icons
⋅⋅* Gregor Cresnar http://www.flaticon.com/free-icon/chat_126499
