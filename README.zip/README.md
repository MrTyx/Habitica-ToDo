# Habitica-ToDo
Create Habitica ToDo item from current tab url


# Credit

1. Success_1.mp3
... NotificationsSounds https://notificationsounds.com/message-tones/filling-your-inbox-251
2. Success_2.mp3
... NotificationsSounds https://notificationsounds.com/notification-sounds/job-done-501
3. Success_3.mp3
... NotificationsSounds https://notificationsounds.com/message-tones/all-eyes-on-me-465

Icons - Gregor Cresnar
http://www.flaticon.com/free-icon/chat_126499
